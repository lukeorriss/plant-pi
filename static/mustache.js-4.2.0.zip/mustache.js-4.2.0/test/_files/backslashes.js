({
  value: '\\abc'
});
